<script language="javascript">
	var sPopupMessage="<%= PopupMessage %>";
	if(sPopupMessage!="")
		alert(sPopupMessage);
		
</script>
<%= FootScript %>